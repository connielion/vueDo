//
//  JMKeychain.h
//  JMSettings
//
//  Created by thonfi on 09/04/15.
//  Copyright (c) 2015 LogMeIn, Inc. All rights reserved.
//

@import CoreFoundation;
#import "JMSettings.h"

CF_EXPORT void JMSLogKeychainInfo(JMSLogger logger);
CF_EXPORT void JMSLogAccessInfo(SecAccessRef access, JMSLogger logger);

CF_EXPORT NSString *JMSKeychainGetValue(NSString *service, NSString *account, JMSLogger logger);
CF_EXPORT BOOL JMSKeychainHasValue(NSString *service, NSString *account, JMSLogger logger);
CF_EXPORT BOOL JMSKeychainSetValue(NSString *service, NSString *account, NSString *label, NSString *value, SecAccessRef access, JMSLogger logger);
CF_EXPORT BOOL JMSKeychainRemoveValue(NSString *service, NSString *account, JMSLogger logger);

CF_EXPORT SecTrustedApplicationRef JMSTrustedApplicationRefCreateFromDesignatedRequirement(NSString *appName, NSString *designatedRequirement, JMSLogger logger);
CF_EXPORT SecAccessRef JMSAccessRefCreateFromDesignatedRequirements(NSString *itemDescription, NSDictionary *trustedApplicationDictionary, JMSLogger logger);

