//
//  JMSSettingsConfig.h
//  JMSettings
//
//  Created by Károly Lőrentey on 2015-05-06.
//  Copyright (c) 2015 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

/// Encapsulates internal configuration parameters of JMSSettings.
@interface JMSSettingsConfig : NSObject
{
@private
    NSString *_applicationID;
    NSString *_keychainPrefix;
    NSDictionary *_designatedRequirements;
    BOOL _userInteractionAllowed;
}

/// The default configuration, to be used in production join.me apps. This is loaded from "join.me-config.plist" in the JMSettings bundle.
+ (instancetype)defaultConfig;

/// Create a JMSSettings configuration from the supplied dictionary. Dictionary keys match the join.me-config.plist in the JMSettings bundle.
/// This is only exported to support unit testing; it shouldn't be used in production code.
+ (instancetype)configFromDictionary:(NSDictionary *)dictionary;

/// The application ID under which settings should be stored. This is the same as the bundle ID of the main join.me application, "com.logmein.join.me".
@property (nonatomic, readonly) NSString *applicationID;

/// All secure settings will have this prefix in the service field of their keychain items. This is "join.me" in the default config.
@property (nonatomic, readonly) NSString *keychainPrefix;

/// A dictionary with the designated requirement strings of all the applications that are to be able to access secure settings.
/// Keys are user-readable application names, values are the designated requirements.
///
/// The designated requirement serves as a secure identity of the application that is stable across app upgrades.
/// You can use 'codesign -d -r- <bundle path>' to get the designated requirement string of any signed app.
///
/// An example designated requirement (taken from the join.me app) is `identifier "com.logmein.join.me" and anchor apple generic and certificate 1[field.1.2.840.113635.100.6.2.6] /* exists */ and certificate leaf[field.1.2.840.113635.100.6.1.13] /* exists */ and certificate leaf[subject.OU] = GFNFVT632V`
///
/// If you leave this dictionary empty, then only the app creating secure settings will have unprompted access to them.
@property (nonatomic, readonly) NSDictionary *designatedRequirements;


@property (nonatomic, readonly) BOOL userInteractionAllowed;
@end
