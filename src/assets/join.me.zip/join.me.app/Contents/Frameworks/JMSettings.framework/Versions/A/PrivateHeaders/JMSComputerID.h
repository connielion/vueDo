//
//  JMSComputerID.h
//  JMSettings
//
//  Created by Károly Lőrentey on 2015-04-16.
//  Copyright (c) 2015 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "JMSLog.h"

CF_EXTERN_C_BEGIN

NSData *JMSGetComputerID(JMSLogger logger);

CF_EXTERN_C_END
